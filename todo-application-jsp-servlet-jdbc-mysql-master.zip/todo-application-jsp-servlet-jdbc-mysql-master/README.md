# todo-application-jsp-servlet-jdbc-mysql

Refer blog tutorial at 
<a href="https://www.javaguides.net/2019/10/build-todo-app-using-jsp-servlet-jdbc-and-mysql.html"> Build Todo App using JSP, Servlet, JDBC and MySQL</a>
